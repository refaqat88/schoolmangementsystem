 function cl() {
 document.getElementsByClassName("mni")[0].click();
}